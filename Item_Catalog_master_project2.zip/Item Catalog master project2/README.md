## Item catalog
Create a restaurant menu app where users can add, edit, and delete restaurants and menu items in the restaurants.

## How to Run
item_catalog
to run it
1.write 'vagrant up'
2.write 'vagrant ssh'
3.inter to cd/ vagrant
4. write 'python database_setup.py' to create tables in database
5.write 'python fill_database.py' to fill this tables
6.write 'python server.py' 
7.open browser "http://localhost:5000"

## Using Google Login

1- Go to your app's page in the Google APIs Console — https://console.developers.google.com/apis
2- Choose Credentials from the menu on the left.
3- Create an OAuth Client ID.
4- choose Web application.
5- You will then be able to get the client ID and client secret.
6- put your client secret.json on prjoect path